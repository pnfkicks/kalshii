/**
 * ROLE: Kalshi-only trading strategy. No Polymarket. No stop loss.
 *
 * BUY rules — ALL must be true before entering:
 *   1. Ask is between KALSHI_BUY_MIN and KALSHI_BUY_THRESHOLD (30c–45c)
 *   2. Price has been STABLE in that window for STABILITY_TICKS consecutive ticks
 *      (prevents entering while price is actively crashing through the window)
 *   3. At least MIN_OBSERVATION_TICKS ticks have passed since we first saw this market
 *      (prevents entering in the first ~90s when direction is unknown)
 *   4. The side we're buying must NOT have been falling continuously
 *      (momentum filter: skip if price dropped >10c in the last 10 ticks)
 *
 * EXIT:
 *   - Early take-profit if ask hits KALSHI_PROFIT_TARGET
 *   - Otherwise hold — Kalshi auto-settles at expiry ($1.00/contract if correct)
 *   - 409/404 on sell = market already settled, accept auto-payout and move on
 */
import type { DualMarketPrices } from "./dual-monitor";
import { placeOrder, placeSellOrder } from "../kalshi/bot";
import {
  KALSHI_BUY_THRESHOLD,
  KALSHI_BUY_MIN,
  KALSHI_PROFIT_TARGET,
  KALSHI_TRADE_CONTRACTS,
  KALSHI_DRY_RUN,
} from "../core/config";
import { appendMonitorLogWithTimestamp } from "../core/monitor-logger";

// ── Tuning ────────────────────────────────────────────────────────────────────

/** Ticks price must stay in buy window before we enter (2s each = 30s at default poll rate) */
const STABILITY_TICKS = 10;

/** Ticks to observe a new market before allowing any entry (~60s at 2s poll) */
const MIN_OBSERVATION_TICKS = 30;

/** If price dropped more than this many cents in the last TREND_WINDOW ticks, skip entry */
const MAX_DROP_CENTS = 10;
const TREND_WINDOW   = 10;

// ── State ─────────────────────────────────────────────────────────────────────

interface Position {
  ticker: string;
  side: "yes" | "no";
  contracts: number;
  entryPriceCents: number;
}

interface MarketState {
  ticksSeen:      number;           // how many ticks we've observed this market
  stableTicks:    Record<"yes"|"no", number>; // consecutive ticks in buy window
  priceHistory:   Record<"yes"|"no", number[]>; // recent price history
}

let position:        Position | null = null;
let lastTicker:      string | null   = null;
let cycleDoneTicker: string | null   = null;
let strategyBusy     = false;

const marketStates = new Map<string, MarketState>();
const skippedTickers = new Set<string>();
const seenTickers    = new Set<string>();

// ── Helpers ───────────────────────────────────────────────────────────────────

function log(msg: string): void {
  console.log(msg);
  appendMonitorLogWithTimestamp(msg);
}

function clearState(reason: string): void {
  log(`[Kalshi] State cleared (${reason}) — ready for next market`);
  position        = null;
  cycleDoneTicker = null;
}

function resetOnNewTicker(ticker: string): void {
  if (lastTicker !== null && lastTicker !== ticker) {
    if (position) {
      log(`[Kalshi] New market ${ticker} — previous position on ${position.ticker} settled by Kalshi`);
    }
    clearState("new market detected");
  }
  lastTicker = ticker;
}

function getMarketState(ticker: string): MarketState {
  if (!marketStates.has(ticker)) {
    marketStates.set(ticker, {
      ticksSeen:    0,
      stableTicks:  { yes: 0, no: 0 },
      priceHistory: { yes: [], no: [] },
    });
  }
  return marketStates.get(ticker)!;
}

function updateMarketState(state: MarketState, yesAsk: number, noAsk: number): void {
  state.ticksSeen++;

  // Update stable ticks for each side
  for (const [side, ask] of [["yes", yesAsk], ["no", noAsk]] as const) {
    if (ask >= KALSHI_BUY_MIN && ask <= KALSHI_BUY_THRESHOLD) {
      state.stableTicks[side]++;
    } else {
      state.stableTicks[side] = 0; // reset if price leaves window
    }
    // Keep last TREND_WINDOW prices
    state.priceHistory[side].push(ask);
    if (state.priceHistory[side].length > TREND_WINDOW + 2) {
      state.priceHistory[side].shift();
    }
  }
}

/** True if the side's price has dropped more than MAX_DROP_CENTS recently (falling knife) */
function isFallingKnife(state: MarketState, side: "yes" | "no"): boolean {
  const hist = state.priceHistory[side];
  if (hist.length < TREND_WINDOW) return false;
  const oldest = hist[0];
  const newest = hist[hist.length - 1];
  return (oldest - newest) >= MAX_DROP_CENTS; // dropped hard recently
}

function isTradeable(cents: number): boolean {
  return cents >= KALSHI_BUY_MIN && cents <= KALSHI_BUY_THRESHOLD;
}

function isMarketSettled(yesAsk: number, noAsk: number): boolean {
  return yesAsk <= 1 || noAsk <= 1 || yesAsk >= 99 || noAsk >= 99;
}

function isSettlementError(errMsg: string): boolean {
  return errMsg.includes("409") || errMsg.includes("404") ||
         errMsg.includes("not_found") || errMsg.includes("closed") ||
         errMsg.includes("settled");
}

// ── Main tick ─────────────────────────────────────────────────────────────────

export async function checkKalshi1PolyStrategy(
  p: DualMarketPrices
): Promise<void> {
  if (!p.kalshi) return;
  if (strategyBusy) return;
  strategyBusy = true;

  try {
    const ticker = p.kalshiTicker;
    resetOnNewTicker(ticker);

    const yesAsk = p.kalshi.upAskCents;
    const noAsk  = p.kalshi.downAskCents;

    const state = getMarketState(ticker);
    updateMarketState(state, yesAsk, noAsk);

    // ── Auto-clear on terminal prices (market settled) ─────────────────────
    if (position && position.ticker === ticker && isMarketSettled(yesAsk, noAsk)) {
      const winSide = yesAsk >= 99 ? "YES" : "NO";
      const ourSide = position.side.toUpperCase();
      const outcome = ourSide === winSide ? "✓ WON — Kalshi will auto-pay" : "✗ LOST";
      log(`[Kalshi] Market settled: ${winSide} wins. Our side: ${ourSide}. ${outcome}`);
      clearState("market settled — terminal prices detected");
      return;
    }

    // ── Skip markets that opened already near-resolved ─────────────────────
    if (!seenTickers.has(ticker)) {
      seenTickers.add(ticker);
      // Skip if either side is outside tradeable range on first sight
      if (yesAsk < KALSHI_BUY_MIN || noAsk < KALSHI_BUY_MIN || yesAsk >= 99 || noAsk >= 99) {
        skippedTickers.add(ticker);
        log(`[Kalshi] Skip ${ticker}: opened out of range (YES=${yesAsk}c NO=${noAsk}c)`);
        return;
      }
      // Skip if market is already trending hard — both sides should be near 50/50
      // If the spread between sides is > 30c, the market has already made up its mind
      const spread = Math.abs(yesAsk - noAsk);
      if (spread > 30) {
        skippedTickers.add(ticker);
        log(
          `[Kalshi] Skip ${ticker}: market already trending (YES=${yesAsk}c NO=${noAsk}c` +
          ` spread=${spread}c > 30c). Waiting for next candle.`
        );
        return;
      }
    }
    if (skippedTickers.has(ticker)) return;
    if (cycleDoneTicker === ticker) return;

    // ── HOLD: check for early take-profit ──────────────────────────────────
    if (position && position.ticker === ticker) {
      const currentAsk = position.side === "yes" ? yesAsk : noAsk;

      if (currentAsk >= KALSHI_PROFIT_TARGET) {
        log(
          `[Kalshi] TAKE PROFIT ${position.side.toUpperCase()} @ ${currentAsk}c` +
          ` (target ${KALSHI_PROFIT_TARGET}c) — selling ${position.contracts} contracts`
        );
        if (!KALSHI_DRY_RUN) {
          const result = await placeSellOrder(
            position.ticker, position.side, position.contracts, { arbLive: true }
          );
          if ("error" in result) {
            if (isSettlementError(result.error)) {
              log(`[Kalshi] Sell blocked (${result.error}) — market settled by Kalshi, accepting auto-payout`);
              clearState("sell rejected — market settled");
            } else {
              log(`[Kalshi] Sell failed (${result.error}) — will retry next tick`);
            }
            return;
          }
        }
        log(`[Kalshi] ✓ Profit exit — sold ${position.contracts} contracts @ ${currentAsk}c`);
        clearState("profit exit successful");
        return;
      }

      const pnlDir = currentAsk > position.entryPriceCents ? "▲" : "▼";
      log(
        `[Kalshi] HOLDING ${position.side.toUpperCase()} — entry ${position.entryPriceCents}c` +
        ` | now ${currentAsk}c ${pnlDir}` +
        ` | early exit ≥ ${KALSHI_PROFIT_TARGET}c | otherwise holds to settlement`
      );
      return;
    }

    // ── ENTRY: all filters must pass ───────────────────────────────────────
    const buyYes = isTradeable(yesAsk);
    const buyNo  = isTradeable(noAsk);

    if (!buyYes && !buyNo) return; // nothing in range this tick

    // Filter 1: minimum observation period
    if (state.ticksSeen < MIN_OBSERVATION_TICKS) {
      const remaining = MIN_OBSERVATION_TICKS - state.ticksSeen;
      log(
        `[Kalshi] ${ticker} — YES ${yesAsk}c NO ${noAsk}c` +
        ` | observing... ${remaining} ticks left before entry allowed`
      );
      return;
    }

    // Pick candidate side (cheapest qualifying, ties go to YES)
    const side: "yes" | "no" =
      buyYes && (!buyNo || yesAsk <= noAsk) ? "yes" : "no";
    const entryPrice = side === "yes" ? yesAsk : noAsk;

    // Filter 2: price must be stable in window (not actively crashing through it)
    if (state.stableTicks[side] < STABILITY_TICKS) {
      log(
        `[Kalshi] ${ticker} — ${side.toUpperCase()} @ ${entryPrice}c` +
        ` | waiting for stability (${state.stableTicks[side]}/${STABILITY_TICKS} ticks)`
      );
      return;
    }

    // Filter 3: falling knife check (don't catch a falling price)
    if (isFallingKnife(state, side)) {
      log(
        `[Kalshi] ${ticker} — ${side.toUpperCase()} @ ${entryPrice}c` +
        ` | SKIP: falling knife (dropped ≥${MAX_DROP_CENTS}c in last ${TREND_WINDOW} ticks)`
      );
      return;
    }

    // All filters passed — enter
    log(
      `[Kalshi] ENTRY ${side.toUpperCase()} @ ${entryPrice}c` +
      ` | stable ${state.stableTicks[side]} ticks | observed ${state.ticksSeen} ticks` +
      ` | buying ${KALSHI_TRADE_CONTRACTS} contracts` +
      ` | max profit $${((100 - entryPrice) * KALSHI_TRADE_CONTRACTS / 100).toFixed(2)} at settlement`
    );

    if (!KALSHI_DRY_RUN) {
      const buyResult = await placeOrder(
        ticker, side, KALSHI_TRADE_CONTRACTS, entryPrice, { arbLive: true }
      );
      if ("error" in buyResult) {
        log(`[Kalshi] Buy failed: ${buyResult.error}`);
        return;
      }
      position = { ticker, side, contracts: KALSHI_TRADE_CONTRACTS, entryPriceCents: entryPrice };
    } else {
      log(`[Kalshi] [DRY RUN] Would buy ${side.toUpperCase()} x${KALSHI_TRADE_CONTRACTS} @ ${entryPrice}c`);
      position = { ticker, side, contracts: KALSHI_TRADE_CONTRACTS, entryPriceCents: entryPrice };
    }

  } finally {
    strategyBusy = false;
  }
}

/**
 * ROLE: Entry point. Kalshi-only monitor + strategy.
 * Polls Kalshi prices every KALSHI_MONITOR_INTERVAL_MS ms.
 * On each tick: logs prices, runs Kalshi-only buy/sell strategy.
 */
import { startDualPriceMonitor, formatDualPricesLine } from "./dual-monitor";
import { checkKalshi1PolyStrategy } from "./kalshi-1-poly-strategy";
import { warmKalshiOrdersApi, getKalshiBalanceCents } from "../kalshi/bot";
import { appendMonitorLog } from "../core/monitor-logger";
import { acquireMonitorLock, releaseMonitorLock } from "../core/monitor-lock";
import { validateRequiredEnvOrExit } from "../core/validate-env";
import {
  MIN_BALANCE_USD,
  KALSHI_BUY_THRESHOLD,
  KALSHI_PROFIT_TARGET,
  KALSHI_STOP_LOSS,
  KALSHI_TRADE_CONTRACTS,
  KALSHI_DRY_RUN,
} from "../core/config";

async function checkBalancesOrExit(): Promise<void> {
  const minCents = Math.round(MIN_BALANCE_USD * 100);
  const kalshiCents = await getKalshiBalanceCents();

  if (kalshiCents < minCents) {
    console.error(
      `[Balance] Kalshi balance $${(kalshiCents / 100).toFixed(2)} is below minimum $${MIN_BALANCE_USD}. Stopping.`
    );
    process.exit(1);
  }
  console.log(`[Balance] Kalshi $${(kalshiCents / 100).toFixed(2)} ✓`);
}

async function main(): Promise<void> {
  validateRequiredEnvOrExit();
  acquireMonitorLock();
  await checkBalancesOrExit();

  const intervalMs = parseInt(process.env.KALSHI_MONITOR_INTERVAL_MS ?? "2000", 10);
  const ticker = process.env.KALSHI_MONITOR_TICKER;
  // Auto-restart via process spawn doesn't work on Windows (EFTYPE).
  // Markets are refreshed automatically each quarter-hour within the monitor loop.
  const restartOnQuarterHour = false;

  console.log(
    `[Kalshi] Strategy: buy when ask <= ${KALSHI_BUY_THRESHOLD}c` +
    ` | take profit >= ${KALSHI_PROFIT_TARGET}c` +
    ` | stop loss <= ${KALSHI_STOP_LOSS}c` +
    ` | size ${KALSHI_TRADE_CONTRACTS} contracts` +
    (KALSHI_DRY_RUN ? " | DRY RUN (no real orders)" : " | LIVE TRADING")
  );
  console.log(
    `[Kalshi] Polling every ${intervalMs}ms` +
    (ticker ? ` | fixed ticker: ${ticker}` : " | auto first open BTC 15m market") +
    (restartOnQuarterHour && !ticker ? " | restarts at :00/:15/:30/:45" : "")
  );

  warmKalshiOrdersApi();

  const stop = await startDualPriceMonitor({
    kalshiTicker: ticker || undefined,
    intervalMs,
    restartProcessOnQuarterHour: restartOnQuarterHour,
    onPrices: (p) => {
      checkKalshi1PolyStrategy(p).catch((err: unknown) => {
        console.error("[Kalshi] Strategy error:", err);
      });
      // Always print live prices to console on every tick
      if (p.kalshi) {
        const yesAsk = (p.kalshi.upAskCents / 100).toFixed(2);
        const noAsk  = (p.kalshi.downAskCents / 100).toFixed(2);
        const last   = (p.kalshi.lastPriceCents / 100).toFixed(2);
        const time   = p.fetchedAt.toISOString().slice(11, 19);
        const priceLine = `[${time}] ${p.kalshiTicker} | YES ask=${yesAsk}  NO ask=${noAsk}  last=${last}`;
        console.log(priceLine);
        appendMonitorLog(priceLine, p.fetchedAt);
      }
    },
    onError: (err) => {
      console.error("[Monitor] Error:", err);
    },
  });

  process.on("SIGINT", () => {
    console.log("\n[Kalshi] Stopping...");
    stop();
    releaseMonitorLock();
    process.exit(0);
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

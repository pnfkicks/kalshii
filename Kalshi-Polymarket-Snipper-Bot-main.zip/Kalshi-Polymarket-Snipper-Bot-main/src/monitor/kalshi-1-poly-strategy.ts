/**
 * ROLE: Kalshi-only trading strategy. No Polymarket. No stop loss.
 *
 * BUY:  When YES or NO ask is between KALSHI_BUY_MIN and KALSHI_BUY_THRESHOLD.
 *       Skip markets where either side opened outside that range (already resolved).
 *
 * EXIT: Early take-profit ONLY — sell if price rises to KALSHI_PROFIT_TARGET.
 *       Otherwise hold and let Kalshi settle at expiry (pays full $1.00/contract).
 *
 * One buy per 15-min market ticker, then waits for the next candle.
 */
import type { DualMarketPrices } from "./dual-monitor";
import { placeOrder, placeSellOrder } from "../kalshi/bot";
import {
  KALSHI_BUY_THRESHOLD,
  KALSHI_BUY_MIN,
  KALSHI_PROFIT_TARGET,
  KALSHI_TRADE_CONTRACTS,
  KALSHI_DRY_RUN,
} from "../core/config";
import { appendMonitorLogWithTimestamp } from "../core/monitor-logger";

// ── State ────────────────────────────────────────────────────────────────────

interface Position {
  ticker: string;
  side: "yes" | "no";
  contracts: number;
  entryPriceCents: number;
}

let position: Position | null = null;
let lastTicker: string | null = null;
let cycleDoneTicker: string | null = null;
let strategyBusy = false;

const skippedTickers = new Set<string>();
const seenTickers = new Set<string>();

// ── Helpers ──────────────────────────────────────────────────────────────────

function log(msg: string): void {
  console.log(msg);
  appendMonitorLogWithTimestamp(msg);
}

function resetOnNewTicker(ticker: string): void {
  if (lastTicker !== null && lastTicker !== ticker) {
    // New candle started — clear position (Kalshi will have settled the old one)
    if (position) {
      log(`[Kalshi] New market ${ticker} — previous position on ${position.ticker} left to settle at expiry`);
    }
    position = null;
    cycleDoneTicker = null;
  }
  lastTicker = ticker;
}

function isTradeable(cents: number): boolean {
  return cents >= KALSHI_BUY_MIN && cents <= KALSHI_BUY_THRESHOLD;
}

// ── Main strategy tick ────────────────────────────────────────────────────────

export async function checkKalshi1PolyStrategy(
  p: DualMarketPrices
): Promise<void> {
  if (!p.kalshi) return;
  if (strategyBusy) return;
  strategyBusy = true;

  try {
    const ticker = p.kalshiTicker;
    resetOnNewTicker(ticker);

    const yesAsk = p.kalshi.upAskCents;
    const noAsk  = p.kalshi.downAskCents;

    // ── Skip markets that opened already near-resolved ─────────────────────
    if (!seenTickers.has(ticker)) {
      seenTickers.add(ticker);
      if (yesAsk < KALSHI_BUY_MIN || noAsk < KALSHI_BUY_MIN || yesAsk >= 99 || noAsk >= 99) {
        skippedTickers.add(ticker);
        log(
          `[Kalshi] Skip ${ticker}: prices out of tradeable range on open ` +
          `(YES=${yesAsk}c NO=${noAsk}c). Need both sides between ${KALSHI_BUY_MIN}c–99c.`
        );
        return;
      }
    }
    if (skippedTickers.has(ticker)) return;
    if (cycleDoneTicker === ticker) return;

    // ── HOLD: only exit early on take-profit — NO stop loss ────────────────
    if (position) {
      const currentAsk = position.side === "yes" ? yesAsk : noAsk;

      if (currentAsk >= KALSHI_PROFIT_TARGET) {
        log(
          `[Kalshi] TAKE PROFIT ${position.side.toUpperCase()} @ ${currentAsk}c` +
          ` (target ${KALSHI_PROFIT_TARGET}c) — selling ${position.contracts} contracts early`
        );
        if (!KALSHI_DRY_RUN) {
          const result = await placeSellOrder(
            position.ticker,
            position.side,
            position.contracts,
            { arbLive: true }
          );
          if ("error" in result) {
            log(`[Kalshi] Early sell failed: ${result.error} — will hold to expiry instead`);
            // Don't clear position — let it settle at expiry, that's fine
            return;
          }
        }
        cycleDoneTicker = ticker;
        position = null;
        return;
      }

      // Still holding — log current status, no stop loss
      const pnlDir = currentAsk > position.entryPriceCents ? "▲" : "▼";
      log(
        `[Kalshi] HOLDING ${position.side.toUpperCase()} — entry ${position.entryPriceCents}c` +
        ` | current ${currentAsk}c ${pnlDir}` +
        ` | early exit if >= ${KALSHI_PROFIT_TARGET}c | otherwise holds to settlement`
      );
      return;
    }

    // ── ENTRY: find a side in the buy window ──────────────────────────────
    const buyYes = isTradeable(yesAsk);
    const buyNo  = isTradeable(noAsk);

    if (!buyYes && !buyNo) {
      // Prices already shown in runner — nothing to act on this tick
      return;
    }

    // Prefer whichever is in the buy window; if both qualify, pick the cheaper one
    const side: "yes" | "no" =
      buyYes && (!buyNo || yesAsk <= noAsk) ? "yes" : "no";
    const entryPrice = side === "yes" ? yesAsk : noAsk;

    log(
      `[Kalshi] ENTRY ${side.toUpperCase()} @ ${entryPrice}c` +
      ` (window ${KALSHI_BUY_MIN}c–${KALSHI_BUY_THRESHOLD}c)` +
      ` — buying ${KALSHI_TRADE_CONTRACTS} contracts` +
      ` | max profit ${((100 - entryPrice) * KALSHI_TRADE_CONTRACTS / 100).toFixed(2)}` +
      ` if held to settlement`
    );

    if (!KALSHI_DRY_RUN) {
      const buyResult = await placeOrder(
        ticker,
        side,
        KALSHI_TRADE_CONTRACTS,
        entryPrice,
        { arbLive: true }
      );

      if ("error" in buyResult) {
        log(`[Kalshi] Buy failed: ${buyResult.error}`);
        return;
      }

      position = { ticker, side, contracts: KALSHI_TRADE_CONTRACTS, entryPriceCents: entryPrice };
    } else {
      log(`[Kalshi] [DRY RUN] Would buy ${side.toUpperCase()} x${KALSHI_TRADE_CONTRACTS} @ ${entryPrice}c`);
      position = { ticker, side, contracts: KALSHI_TRADE_CONTRACTS, entryPriceCents: entryPrice };
    }
  } finally {
    strategyBusy = false;
  }
}
